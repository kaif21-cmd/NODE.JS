// showing file to server...
const fs=require("fs")
const http=require("http")
const server=http.createServer((req,res)=>{
    var fs=require("fs");
    fs.readFile("input.txt",(err,data)=>{
        if(err) return console.error(err);
    res.end(data.toString());
});
});
    
server.listen(8000,"127.0.0.1",()=>{
    console.log("listing to server")
})